# investment_telegram_bot
Telegram-bot with personal cabinet, crypto-currency purse, purchase of tokens and conversion of crypto currency.

Live: @cryptosreda_bot or http://t.me/cryptosreda_bot 
Send "/ author" to the chat to get information about me
